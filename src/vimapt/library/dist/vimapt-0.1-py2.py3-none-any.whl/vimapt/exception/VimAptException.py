class VimAptException(Exception):
    pass
