#!/usr/bin/env python
#-*- coding:utf8 -*-

from setuptools import setup
from setuptools import find_packages

setup(
    name="vimapt-tools",
    version="0.1",
    packages=find_packages(),
    include_package_data=True,

    description="command tools for vimapt",
    long_description="vimapt is a vim package manager. this is the command tools for vimapt",
    author="howlanderson",
    author_email="u1mail2me@gmail.com",

    license="GPL",
    keywords="vimapt vim plugin tools",
    platforms="Independant",
    url="http://www.howlanderson.net",
)
