#!/usr/bin/env python

class Package:
    def __init__(self, vim_dir, package_name):
        pass

    def get_version(self):
        pass

    def get_control_data(self):
        pass

    def get_copyright_data(self):
        pass

    def get_changelog_data(self):
        pass
